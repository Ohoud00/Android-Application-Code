package com.example.seniorproject;

import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

public class progressbar extends AppCompatActivity {
    private ProgressBar progressBar ;
    private TextView scan_comp;
    private int counter=0;
    //  private Handler mhandler=new Handler();

    Handler rhandler=new Handler(){
        @Override
        public void handleMessage(Message msg) {
            scan_comp=( TextView)findViewById(R.id.scan_com);
            scan_comp.setText("The Scan is complete");
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_progressbar);


        progressBar=(ProgressBar)findViewById(R.id.progrees_bar);


//the code below works just fine

//new Thread(new Runnable() {
//    @Override
//    public void run() {
//        while (counter<100){
//            counter++;
//            android.os.SystemClock.sleep(100);//the number need to change according to our scan function,the current number realy low
//            mhandler.post(new Runnable() {
//                @Override
//                public void run() {
//                    progressBar.setProgress(counter);//to update the progress bar
//
//
//                }
//            });
//        }//end loop
//mhandler.post(new Runnable() {
//    @Override
//    public void run() {
//        scan_comp.setText("The Scan is complete");
//    }
//});
//    }
//}).start();


//create a object from runnable , and put the code take to much time in it
        Runnable r=new Runnable() {
            @Override
            public void run() {
                while (counter<100){
                    counter++;
                    android.os.SystemClock.sleep(100);//the number need to change according to our scan function,the current number realy low
                    rhandler.post(new Runnable() {
                        @Override
                        public void run() {
                            progressBar.setProgress(counter);//to update the progress bar


                        }
                    });
                }//end loop
                rhandler.sendEmptyMessage(0);//to call the handler
            }
        } ;
        Thread rthread=new Thread(r);
        rthread.start();//to start the thread



    }//main
}//clAss