package com.example.seniorproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;


///////////////////
///////// create internal DB to recording all threats detection

public class DB_Sqlite extends SQLiteOpenHelper {
    public static final String DBname = "recordedthreats.db";

    public DB_Sqlite(Context context) {
        super(context, DBname, null, 5);

    }


    @Override
    public void onCreate(SQLiteDatabase db) {
/////////// create table
        ////////////////////////////////////////////// insert , date DATE
        db.execSQL("create table RecordedThreatsTable(id INTEGER PRIMARY KEY AUTOINCREMENT , type TEXT ,name TEXT, date TEXT )");
        //////////////////////////// the other table for web searching
        db.execSQL("create table WebsiteTable(id INTEGER PRIMARY KEY AUTOINCREMENT , name TEXT ,url TEXT, date TEXT )");

        db.execSQL("create table AppTable(id INTEGER PRIMARY KEY AUTOINCREMENT , Appname TEXT ,pkjName TEXT, version INTEGER )");


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS RecordedThreatsTable");
        db.execSQL("DROP TABLE IF EXISTS WebsiteTable");
        db.execSQL("DROP TABLE IF EXISTS AppTable");

        onCreate(db);
    }

    //// insert data into database

    public boolean insertDataToDashboard(String type, String name) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        Date c = Calendar.getInstance().getTime();
        SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
        String date = df.format(c);
        contentValues.put("type", type);
        contentValues.put("name", name);
        contentValues.put("date", date);

        long result = db.insert("RecordedThreatsTable", null, contentValues);

        if (result == -1)
            return false;
        else
            return true;

    }

    //////////////راح يتأكد انو الداتا بيس لو فاضيه يعبيها لو لا يمكل ماتش ا
    public boolean insertDataToURLtable() {
        ////////////// check weather database is empty
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor mCursor = db.rawQuery("SELECT * FROM WebsiteTable", null);
        Boolean rowExists;

        if (mCursor.moveToFirst()) {
            // DO SOMETHING WITH CURSOR
            rowExists = false;

        } else {
            // I AM EMPTY
            long result;
            ContentValues contentValues = new ContentValues();

            contentValues.put("name", "Glad Foods");
            contentValues.put("url", "http://www.gladfoods.com");
            contentValues.put("date", "06/02/2019");

            result = db.insert("WebsiteTable", null, contentValues);

            /////////////////////////////////////////2

            contentValues.put("name", "Transimex Logistics");
            contentValues.put("url", "http://www.transimexlogistics.com");
            contentValues.put("date", "06/02/2019");

            result = db.insert("WebsiteTable", null, contentValues);

            ///////////////////////////////////////3

            contentValues.put("name", "Ace Couriers");
            contentValues.put("url", "http://www.acecourierex.com");
            contentValues.put("date", "06/02/2019");

            result = db.insert("WebsiteTable", null, contentValues);

            ///////////////////////////////////////4

            contentValues.put("name", "Alpha Scrap Metals");
            contentValues.put("url", "http://www.alphascrapmetals.com");
            contentValues.put("date", "06/02/2019");

            result = db.insert("WebsiteTable", null, contentValues);

            ///////////////////////////////////////5

            contentValues.put("name", "Global Shipping Services");
            contentValues.put("url", "http://www.glshippingservices.com");
            contentValues.put("date", "06/02/2019");

            result = db.insert("WebsiteTable", null, contentValues);

            /////////// return true to show toast text to me that the data is not empty any more
            rowExists = true;
        }
        return rowExists;
    }

    ///// restore data
    ////////////////////////// نسترجع البيانات عشان نروح ونعرضها

    public ArrayList getAllrecord() {

        ArrayList arrayList = new ArrayList();
        SQLiteDatabase db = this.getReadableDatabase();
        ////////////// اتوقع اقدر من هنا اعمل استدعا للرابط واعمل سيرش
        Cursor res = db.rawQuery("select * from RecordedThreatsTable", null);

        res.moveToFirst();
        while (res.isAfterLast() == false) {
////// depend on what columns i need to be printed
            String t1 = res.getString(0);
            String t2 = res.getString(1);// type
            String t3 = res.getString(2);//name
            String t4 = res.getString(3);//date

            arrayList.add(t1 + "- Malicious type:  " + t2 + "\n" + t3 + " - " + t4);
            res.moveToNext();
        }
        return arrayList;

    }

    //////////////////////////////////////////// DELETE this method .. no need
    public ArrayList getAllrecordURL() {

        ArrayList arrayList = new ArrayList();
        SQLiteDatabase db = this.getReadableDatabase();
        ////////////// اتوقع اقدر من هنا اعمل استدعا للرابط واعمل سيرش
        Cursor res = db.rawQuery("select * from WebsiteTable", null);

        res.moveToFirst();
        while (res.isAfterLast() == false) {
////// depend on what columns i need to be printed
            String t1 = res.getString(0);
            String t2 = res.getString(1);// name
            String t3 = res.getString(2);//url
            String t4 = res.getString(3);//date

            arrayList.add(t1 + "-  " + t2 + "\n" + t3 + " - " + t4);
            res.moveToNext();
        }
        return arrayList;
    }


    public int getAllrecordTosearchURL(String input) {
        String t2 = "";
        int num = -1;
        SQLiteDatabase db = this.getReadableDatabase();
        ////////////// اتوقع اقدر من هنا اعمل استدعا للرابط واعمل سيرش
        Cursor res = db.rawQuery("select * from WebsiteTable", null);

        res.moveToFirst();
        while (res.isAfterLast() == false) {
////// depend on what columns i need to be printed

            t2 = res.getString(2);
            if (t2.equals(input)) {
                ///////// send the information to recorded threats database
                insertDataToDashboard("URL", res.getString(1));
                return num = res.getInt(2);
            }
            res.moveToNext();
        }

        return num;
    }


    public String sendDataWebsite(String URLinput) {
        boolean result = insertDataToURLtable();
        if (result = true) {

            int URLsearch = getAllrecordTosearchURL(URLinput);
            if (URLsearch >= 0)

                return "Harmful Website";
                /////////////////////////// counter for home page
                // showDataURl();
            else return "Safe website";
        }
        return "Database is empty";
    }


    ////////////////////////////////////////////////////
    /////////////////////APPLICATION METHODS/////////////////////////////

    public boolean insertDataToAPPtable() {
        ////////////// check weather database is empty
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor mCursor = db.rawQuery("SELECT * FROM APPTable", null);
        Boolean rowExists;

        if (mCursor.moveToFirst()) {
            // DO SOMETHING WITH CURSOR
            rowExists = false;

        } else {
            // I AM EMPTY

            ContentValues contentValues = new ContentValues();

            contentValues.put("Appname", "HTML Viewer");
            contentValues.put("pkjName", "com.android.htmlviewer");
            contentValues.put("version",9 );

            db.insert("APPTable", null, contentValues);

            /////////////////////////////////////////2
            contentValues.put("Appname", "HTML2 Viewer");
            contentValues.put("pkjName", "com.android2.htmlviewer");
            contentValues.put("version",92 );

            db.insert("APPTable", null, contentValues);

            contentValues.put("Appname", "Calculator");
            contentValues.put("pkjName", "com.android.calculator2");
            contentValues.put("version",9 );

            db.insert("APPTable", null, contentValues);



            /////////// return true to show toast text to me that the data is not empty any more
            rowExists = true;
        }
        return rowExists;
    }


    /////////////////////////////////////////////////////////
////////////////////////////////// search application method
    public void searchApp() {
        //////// to fill  application database
        insertDataToAPPtable();
        ////////////// get the installed application to compare with data base
        application_Installed scanApp = new application_Installed();
        ArrayList<application_Installed.PInfo> pm = scanApp.getPackages();
        String t1 ,t2 , t3= "";
        int num = 0;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from AppTable", null);

        res.moveToFirst();
        while (res.isAfterLast() == false) {
////// depend on what columns i need to be printed

            t1 = res.getString(1);///app name
            t2 = res.getString(2);///app pkj
            t3 = res.getString(3);///app version

            if (t1.equals(pm.get(num).appname) && t2.equals(pm.get(num).pname)
                    &&t3.equals(pm.get(num).versionName)) {
                ///////// send the information to recorded threats database
                insertDataToDashboard("App", res.getString(1));
            }

            //   return num =res.getInt(2);}
            res.moveToNext(); num++;
        }

        // return num;
    }
}