package com.example.seniorproject;


import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TimePicker;
import android.widget.Toast;
import java.util.Calendar;

public class SetScheduleScan extends AppCompatActivity {
    RadioGroup radioGroup;
    String [] listItems;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_schedule_scan);


        /////////// current date
        final Calendar c= Calendar.getInstance();
        final int year = c.get(Calendar.YEAR);
        final int month1 = c.get(Calendar.MONTH);
        final int day = c.get(Calendar.DAY_OF_MONTH);
        final int hour = c.get(Calendar.HOUR_OF_DAY);
        final int minute1 = c.get(Calendar.MINUTE);

        final EditText txtTime =(EditText) findViewById(R.id.inputTime);

//for specific time
        final EditText txtDate =(EditText) findViewById(R.id.inputDate);

/////////////// link the click to define the time withe template
        txtTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                TimePickerDialog timepick=new TimePickerDialog(SetScheduleScan.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        txtTime.setText(hourOfDay+ ":"+ minute);
                    }
                },hour, minute1,true);
                timepick.setTitle("Select Time");
                timepick.show(); }
        });

        txtDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog datePick = new DatePickerDialog(SetScheduleScan.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        txtDate.setText(year+" / "+ month +" / "+ dayOfMonth);
                    }
                },year,month1,day);
                datePick.setTitle("Select Date");
                datePick.show();
            }
        });


        /////////////////////////////////////
        ////////////////////////////////
        radioGroup = (RadioGroup)findViewById(R.id.radioGroup1);
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId  ) {

                switch (checkedId) {
                    case R.id.dailybutton:
                        txtDate.setVisibility(View.INVISIBLE); //For Hide the edit txt "inputDate

                        // add the function af daily scanning
                        //  getWindow().getDecorView().setBackgroundColor(Color.parseColor("#0F9723" ));
                        break;

                    case R.id.weaklybutton:
                        txtDate.setVisibility(View.INVISIBLE); // For Hide the edit txt "inputDate


                        ////////////// display checkbox
                        listItems = new String[]{"Sunday","Monday", "Tuesday","Wednesday","Thursday","Friday","Saturday"};
                        final boolean [] checkDaysArray = new boolean[]{false,false,false,false,false,false,false};
                        DialogCheckBox(listItems, checkDaysArray);

                        break;
                    case R.id.monthlybutton:
                        txtDate.setVisibility(View.INVISIBLE); //For Hide the edit txt "inputDate
                        listItems = new String[]{"January","February", "March" ,"April" ,"May" ,"June","July","August"
                                ,"September" ,"October" ,"November","December"};
                        final boolean [] checkDaysArray2 = new boolean[]{false,false,false,false,false,false,false,false,false,false,false,false};
                        DialogCheckBox(listItems, checkDaysArray2);

                        break;
                    case R.id.specificbutton:

                        txtDate.setVisibility(View.VISIBLE); //For showing

// نخليه لو ضغط البوتون يطلع له تكست عشان نطبق الفنكشن
                        break;
                }


            }
        });
        ///////////// method DialogCheckBox for months and days
    }//main
    public void DialogCheckBox(final String [] listItems, final boolean [] checkDaysArray) {
        AlertDialog.Builder builder = new AlertDialog.Builder(SetScheduleScan.this);
        //boolean array for initial selection items
        // mbuilder.setTitle("..."); // set title of AlertDialog
        // mbuilder.setIcon(R.drawable.icon); // set icon

        //set multichoice
        builder.setMultiChoiceItems(listItems, checkDaysArray, new DialogInterface.OnMultiChoiceClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which, boolean isChecked) {
                // update current focused item's checked state
                checkDaysArray[which] = isChecked;
                // get the current focused item
                String currentItem = listItems[which];
                /////اللي تطلع اشعار انو الاشياء تم اختيارها
                Toast.makeText(SetScheduleScan.this, currentItem + " " + isChecked, Toast.LENGTH_SHORT).show();

            }
        });
        //set positive / yes button click listener
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                ////////// اخزن او اطبع جملة وش الاشياء اللي اختارها مثلا
                /// او انو اخزن اللي اختارها عشان ارسلها لكلاس السكان س
            }
        });

        // set negative/cancel button click listener
        builder.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // do something
            }
        });

        AlertDialog dialog = builder.create();
        // show alert dialog
        dialog.show();


    }//dialogcheckbox method

}//class
