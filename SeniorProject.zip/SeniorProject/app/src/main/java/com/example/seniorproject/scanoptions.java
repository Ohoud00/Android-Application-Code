package com.example.seniorproject;


import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class scanoptions extends AppCompatActivity {
    DB_Sqlite db = new DB_Sqlite(this);
String result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scanoptions);


//in case the user choose URL scan
        final Button scan_url = (Button) findViewById(R.id.ScanUrl);
        scan_url.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder mnbulider = new AlertDialog.Builder(scanoptions.this);
                View mnview = getLayoutInflater().inflate(R.layout.url_scan, null);
                final EditText menterurl = (EditText) mnview.findViewById(R.id.enterurl);
                Button mbuttonscan = (Button) mnview.findViewById(R.id.buttonscan);
                mbuttonscan.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (!menterurl.getText().toString().isEmpty()) {

                            Toast.makeText(scanoptions.this, "Scanning the URL", Toast.LENGTH_SHORT).show();
                            /////////// استدعاء للداتا بيس وعمل ماتش
                            String result1 = db.sendDataWebsite(menterurl.getText().toString());
                            /////// if else result
                            Toast.makeText(scanoptions.this, result1 , Toast.LENGTH_SHORT).show();

                        } else {
                            Toast.makeText(scanoptions.this, "Enter URL", Toast.LENGTH_SHORT).show();

                        }
                    }
                });
                mnbulider.setView(mnview);//هذي الطر يخلي الويندو تقفز
                AlertDialog dialog = mnbulider.create();
                dialog.show();
            }
        });

//////////////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////
        //to open scan applications dialog
        Button scan_apps = (Button) findViewById(R.id.Scanapps);
        scan_apps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder mnbulider1 = new AlertDialog.Builder(scanoptions.this);
                View mnview = getLayoutInflater().inflate(R.layout.activity_scan_now_schedule, null);

                ///////// call scan_now_schedule activity

                Button schedule_button = (Button) mnview.findViewById(R.id.schedule_scan);
                schedule_button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        openschedulescan();
                    }
                });

                ////////////// to start scan from scan now button
                Button scannow_button = (Button) mnview.findViewById(R.id.Scan_now);
                scannow_button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                       Intent intent = new Intent(getBaseContext(), application_Installed.class);
                        startActivity(intent);
                   //     openscanNow();
//db.searchApp();
                       // application_Installed app = new application_Installed();
                       // app.getPackages();
                    }
                });


                mnbulider1.setView(mnview);//هذي الطر يخلي الويندو تقفز
                AlertDialog dialog = mnbulider1.create();
                dialog.show();


            }
        });
    }//main

    public void openschedulescan() {
        Intent intent = new Intent(getBaseContext(), SetScheduleScan.class);
        startActivity(intent);
    }

    public void openscanNow() {
        Intent intent = new Intent(getBaseContext(), progressbar.class);
        startActivity(intent);
    }



}//class
