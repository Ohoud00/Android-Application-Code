package com.example.seniorproject;

import android.content.Intent;
import android.content.pm.PackageInfo;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

import static android.content.Intent.ACTION_MAIN;

public class application_Installed extends AppCompatActivity {

    DB_Sqlite dbClass = new DB_Sqlite(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        //     ArrayList<PInfo> pm = getPackages();
        searchApp();

    }


    class PInfo {
        public String appname = "";
        public String pname = "";
        public String versionName = "";
        public int versionCode = 0;
        public Drawable icon;

        public void prettyPrint() {
            Log.v("TAG", appname + "\t" + pname + "\t" + versionName + "\t" + versionCode);


        }
    }

    ///////////////// print info.
    public ArrayList<PInfo> getPackages() {
        ArrayList<PInfo> apps = getInstalledApps(false); /* false = no system packages */
        final int max = apps.size();
        for (int i = 0; i < max; i++) {
            apps.get(i).prettyPrint();
        }
        return apps;
    }

    private ArrayList<PInfo> getInstalledApps(boolean getSysPackages) {
        ArrayList<PInfo> res = new ArrayList<PInfo>();
        List<PackageInfo> packs = getPackageManager().getInstalledPackages(0);
        for (int i = 0; i < packs.size(); i++) {
            PackageInfo p = packs.get(i);
            if ((!getSysPackages) && (p.versionName == null)) {
                continue;
            }
            PInfo newInfo = new PInfo();
            newInfo.appname = p.applicationInfo.loadLabel(getPackageManager()).toString();
            newInfo.pname = p.packageName;
            newInfo.versionName = p.versionName;
            newInfo.versionCode = p.versionCode;
            newInfo.icon = p.applicationInfo.loadIcon(getPackageManager());
            res.add(newInfo);
        }
        return res;
    }

    public void searchApp() {
        //////// to fill  application database
        dbClass.insertDataToAPPtable();
        ////////////// get the installed application to compare with data base
        // application_Installed scanApp = new application_Installed();
        //  ArrayList<application_Installed.PInfo> pm = scanApp.getPackages();
        ArrayList<PInfo> pm = getPackages();

        String t1, t2, t3 = "";
        SQLiteDatabase db = this.dbClass.getReadableDatabase();
        Cursor res = db.rawQuery("select * from AppTable", null);

        res.moveToFirst();

            while (res.isAfterLast() == false) {
////// depend on what columns i need to be printed

            t1 = res.getString(1);///app name
            t2 = res.getString(2);///app pkj
            t3 = res.getString(3);///app version
            Log.v("TABLE", t1 + "\t" + t2 + "\t" + t3 + "\t");
            for (int i = 0; i < pm.size(); i++) {
                if (t1.equals(pm.get(i).appname) && t2.equals(pm.get(i).pname)
                        && t3.equals(pm.get(i).versionName)) {


                    ///////// send the information to recorded threats database
                   dbClass.insertDataToDashboard("App", res.getString(1));
                }
            }
            res.moveToNext();

            //   return num =res.getInt(2);}

        }

        // return num;
    }

/////////////////////////////////////////////////////////////
////////////////// search method

}