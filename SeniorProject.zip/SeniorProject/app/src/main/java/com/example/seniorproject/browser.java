package com.example.seniorproject;

import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.graphics.Bitmap;
import android.widget.Toast;

public class browser extends AppCompatActivity {

    private EditText editText;
    private Button button;
    private WebView webView;

    Cursor c = null;
    DB_Sqlite db = new DB_Sqlite(this);
    String result;
    //  private static DatabaseHelper mDBHelper ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_browser);

        webView = (WebView) findViewById(R.id.webview);
        editText = (EditText) findViewById(R.id.editTextURL);
        button = (Button) findViewById(R.id.buttonbroswer);


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String url = editText.getText().toString(); // check on database

                editText.setText(url);

                result = db.sendDataWebsite(url);
                /////// if else result
                Toast.makeText(browser.this, result, Toast.LENGTH_SHORT).show();

                webView.loadUrl(url);

                webView.setWebViewClient(new WebViewClient() {

                    @Override
                    public void onPageStarted(WebView view, String url, Bitmap favicon) {
                        // TODO Auto-generated method stub
                        super.onPageStarted(view, url, favicon);
                    }

                    @Override
                    public boolean shouldOverrideUrlLoading(WebView view, String url) {
                        // TODO Auto-generated method stub


                        editText.setText(url);
                        result = db.sendDataWebsite(url);
                        /////// if else result
                        Toast.makeText(browser.this, result, Toast.LENGTH_SHORT).show();
                        view.loadUrl(url);
                        return true;

                    }


                });


            }
        });


    }
    


}
