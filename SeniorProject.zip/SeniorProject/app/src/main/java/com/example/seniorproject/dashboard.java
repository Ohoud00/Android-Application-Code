package com.example.seniorproject;

import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
//////////// linked with DB_Sqlite class
public class dashboard extends AppCompatActivity {
    DB_Sqlite db = new DB_Sqlite(this);
    ListView lst;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        ////////// to print the dashboard in listview
        lst = findViewById(R.id.listView_data);
        //boolean result = db.insertDataTourltable("GOOGLE2", "HTTP//:google.com2","2/3/12342" );
        //showDataURl();
        showData();

    //    searchItems();

    }



    /////////// show database
///////// اذا بغينا تنعرض الداتا بس نسوي استدعاء للميثود
    public void  showData (){
        ArrayList<String> listData = db.getAllrecord();
        ArrayAdapter arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1,listData);
        lst.setAdapter(arrayAdapter);




    }

    /////// send the data to database





////////////////////////////// website onclick button
//    public void sendDataWebsite(String URLinput) {
//        boolean result = db.insertDataTourltable();
//        if (result = true){
//            Toast.makeText(this,"Done",Toast.LENGTH_SHORT).show();
//            searchURL(URLinput);
//           // showDataURl();
//        }
//        else
//            Toast.makeText(this,"Failed",Toast.LENGTH_SHORT).show();
//    }

    public void  showDataURl (){
        ArrayList<String> listData = db.getAllrecordURL();
        ArrayAdapter arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1,listData);
        lst.setAdapter(arrayAdapter);




    }
}
